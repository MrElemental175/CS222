Tuition = 8000
year = 1
for num in range(5):
    Tuition = Tuition + (8000 * .03)
    print("After", year , "year(s) the tution per semester will be" , Tuition)
    year = year + 1
    
