Sum = 0
for counter in range(2,101,2):
    Sum = Sum + counter

print(Sum)
    